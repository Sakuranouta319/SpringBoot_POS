-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 伺服器版本:                        10.4.12-MariaDB - mariadb.org binary distribution
-- 伺服器作業系統:                      Win64
-- HeidiSQL 版本:                  11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 傾印 soymilk_pos 的資料庫結構
CREATE DATABASE IF NOT EXISTS `soymilk_pos` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `soymilk_pos`;

-- 傾印  資料表 soymilk_pos.order_detail 結構
CREATE TABLE IF NOT EXISTS `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_num` varchar(20) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `product_price` int(11) DEFAULT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_order_detail_product` (`product_id`),
  KEY `FK_order_detail_sale_order` (`order_num`),
  CONSTRAINT `FK_order_detail_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `FK_order_detail_sale_order` FOREIGN KEY (`order_num`) REFERENCES `sale_order` (`order_num`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- 正在傾印表格  soymilk_pos.order_detail 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
INSERT INTO `order_detail` (`id`, `order_num`, `product_id`, `quantity`, `product_price`, `product_name`) VALUES
	(13, 'ord-101', 'w-c-001', 3, 25, '飯糰'),
	(14, 'ord-102', 'w-c-001', 1, 25, '飯糰'),
	(15, 'ord-102', 'w-s-002', 1, 10, '蔥蛋'),
	(16, 'ord-103', 'w-f-001', 1, 20, '甜豆漿'),
	(17, 'ord-103', 'w-c-001', 1, 25, '飯糰'),
	(18, 'ord-104', 'w-s-004', 1, 20, '蛋餅'),
	(19, 'ord-104', 'w-c-008', 1, 12, '黑糖饅頭'),
	(20, 'ord-105', 'w-c-008', 1, 12, '黑糖饅頭'),
	(21, 'ord-106', 'w-c-001', 1, 25, '飯糰'),
	(22, 'ord-107', 'w-c-001', 1, 25, '飯糰');
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;

-- 傾印  資料表 soymilk_pos.product 結構
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` varchar(10) NOT NULL,
  `category` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(50) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`product_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  soymilk_pos.product 的資料：~20 rows (近似值)
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`product_id`, `category`, `name`, `price`, `photo`, `description`) VALUES
	('w-c-001', '飯糰燒餅', '飯糰', 25, 'w-c-001.jpg', '又大又粗的飯糰'),
	('w-c-002', '飯糰燒餅', '燒餅', 15, 'w-c-002.jpg', '香噴噴的燒餅'),
	('w-c-003', '飯糰燒餅', '燒餅油條', 30, 'w-c-003.jpg', '一定要吃的燒餅油條'),
	('w-c-004', '飯糰燒餅', '燒餅夾蛋', 25, 'w-c-004.jpg', '燒餅夾蛋好吃'),
	('w-c-005', '飯糰燒餅', '燒餅夾豬肉', 40, 'w-c-005.jpg', '燒餅夾豬肉別有一番風味'),
	('w-c-006', '飯糰燒餅', '燒餅夾牛肉', 40, 'w-c-006.jpg', '高級的享受燒餅夾牛肉'),
	('w-c-007', '飯糰燒餅', '鰻頭', 10, 'w-c-007.jpg', '拳頭大的饅頭'),
	('w-c-008', '飯糰燒餅', '黑糖饅頭', 12, 'w-c-008.jpg', '黑糖風味的鰻頭'),
	('w-c-009', '飯糰燒餅', '巧克力鰻頭', 12, 'w-c-009.jpg', '香甜巧克力鰻頭'),
	('w-f-001', '豆漿', '甜豆漿', 20, 'w-f-001.jpg', '最初的好滋味甜豆漿'),
	('w-f-002', '豆漿', '鹹豆漿', 20, 'w-f-002.jpg', '台灣人愛喝的鹹豆漿'),
	('w-f-003', '豆漿', '黑豆漿', 20, 'w-f-003.jpg', '豐富營養成分黑豆漿'),
	('w-f-004', '豆漿', '紅茶', 15, 'w-f-004.jpg', '就只是紅茶而已'),
	('w-f-005', '豆漿', '豆漿紅茶', 20, 'w-f-005.jpg', '加了豆漿就是不一樣的豆漿紅茶'),
	('w-s-001', '蛋餅', '煎蛋', 10, 'w-s-001.jpg', '運氣好會有雙胞胎蛋黃的煎蛋'),
	('w-s-002', '蛋餅', '蔥蛋', 10, 'w-s-002.jpg', '加蔥了的蛋'),
	('w-s-003', '蛋餅', '熱狗', 15, 'w-s-003.jpg', '又粗又長的熱狗'),
	('w-s-004', '蛋餅', '蛋餅', 20, 'w-s-004.jpg', '手工製作蛋餅'),
	('w-s-005', '蛋餅', '玉米蛋餅', 30, 'w-s-005.jpg', '常見的玉米蛋餅'),
	('w-s-006', '蛋餅', '培根蛋餅', 30, 'w-s-006.jpg', '好吃的培根蛋餅');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;

-- 傾印  資料表 soymilk_pos.sale_order 結構
CREATE TABLE IF NOT EXISTS `sale_order` (
  `order_num` varchar(20) CHARACTER SET utf8 NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `total_price` double(22,0) NOT NULL DEFAULT 0,
  `customer_name` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `customer_address` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `customer_phone` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`order_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 正在傾印表格  soymilk_pos.sale_order 的資料：~7 rows (近似值)
/*!40000 ALTER TABLE `sale_order` DISABLE KEYS */;
INSERT INTO `sale_order` (`order_num`, `order_date`, `total_price`, `customer_name`, `customer_address`, `customer_phone`) VALUES
	('ord-101', '2021-05-26 10:21:04', 75, '林同學', '高雄市楠梓', '0905178421'),
	('ord-102', '2021-06-22 21:04:35', 35, '林同學', '高雄市楠梓', '0905178421'),
	('ord-103', '2021-06-23 00:31:24', 45, '林同學', '高雄市楠梓區大學路一號', '093256789'),
	('ord-104', '2021-06-23 00:33:48', 32, '王範例', '高雄市楠梓區大學路一號', '093256789'),
	('ord-105', '2021-06-23 00:35:23', 12, '王範例', '高雄市楠梓區大學路一號', '093256789'),
	('ord-106', '2021-06-23 10:02:19', 25, '林同學', '高雄市楠梓區大學路一號', '0912123456'),
	('ord-107', '2021-06-23 11:16:23', 25, '林同學', '高雄市楠梓區大學路一號', '093256789');
/*!40000 ALTER TABLE `sale_order` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
